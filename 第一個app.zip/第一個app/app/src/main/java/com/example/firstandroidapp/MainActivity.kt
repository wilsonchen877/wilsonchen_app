package com.example.firstandroidapp
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NumericPadScreen() } // 設定畫面為我們的鍵盤
    }
}

@Composable
fun NumericPadScreen() {
    var display by remember { mutableStateOf("0") } // 顯示文字的狀態，一開始是 "0"

    @Composable
    fun DigitButton(label: String, modifier: Modifier = Modifier) {
        Button(
            onClick = { display = label },
            modifier = modifier
                .padding(6.dp)
                .fillMaxHeight(),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
//                containerColor = Color.LightGray, // ← 按鈕背景淺灰色
//                contentColor = Color.Black        // ← 按鈕文字黑色
            )
        ) {
            Text(label, fontSize = 28.sp)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // 顯示區
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
                .background(Color(0xFFEEEEEE), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(text = display, fontSize = 36.sp, fontWeight = FontWeight.Bold)
        }

        Row(Modifier.weight(1f)) {
            DigitButton("C", Modifier.weight(1f))
            Spacer(modifier = Modifier.weight(2f))
            DigitButton("÷", Modifier.weight(1f))
        }
        // 第一列：1 2 3
        Row(Modifier.weight(1f)) {
            DigitButton("1", Modifier.weight(1f))
            DigitButton("2", Modifier.weight(1f))
            DigitButton("3", Modifier.weight(1f))
            DigitButton("x", Modifier.weight(1f))
        }
        // 第二列：4 5 6
        Row(Modifier.weight(1f)) {
            DigitButton("4", Modifier.weight(1f))
            DigitButton("5", Modifier.weight(1f))
            DigitButton("6", Modifier.weight(1f))
            DigitButton("+", Modifier.weight(1f))
        }
        // 第三列：7 8 9
        Row(Modifier.weight(1f)) {
            DigitButton("7", Modifier.weight(1f))
            DigitButton("8", Modifier.weight(1f))
            DigitButton("9", Modifier.weight(1f))
            DigitButton("-", Modifier.weight(1f))
        }

        Row(Modifier.weight(1f)) {
            DigitButton("0", Modifier.weight(1f))
            DigitButton(".", Modifier.weight(1f))
            DigitButton("Del", Modifier.weight(1f))
            DigitButton("=", Modifier.weight(1f))
        }
        // 最下列：中間一顆 0（左右用 Spacer 撐開）
//        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
//            Spacer(Modifier.weight(1f))
//            DigitButton("0", Modifier.weight(1f))
//            Spacer(Modifier.weight(1f))
        }
    }

